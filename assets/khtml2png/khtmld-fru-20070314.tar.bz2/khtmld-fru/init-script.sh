#!/bin/sh

#USER=khtml# User which can run khtml2png
USER=openoffice

PID=/tmp/khtmld.pid
SPOOL=/tmp/khtmld.spool
K2PCONFIG=/home/${USER}/.khtmldrc

#K2PPATH=/usr/local/bin/khtml2png2
#DAEMONPATH=/usr/local/sbin/khtmld
K2PPATH=/home/x2003bruneau/khtml2png-2.6.0/khtml2png2
DAEMONPATH=/home/x2003bruneau/khtmld-fru/khtmld

start()
{
   ${DAEMONPATH} -D -c ${K2PCONFIG} -K ${K2PPATH} -u ${USER} -p ${PID} -s ${SPOOL}
}

stop()
{
    ( [ -f ${PID} ] && kill -15 `cat ${PID}` 2> /dev/null ) || echo "No process found"
    rm ${PID} 2> /dev/null
    rm ${SPOOL} 2> /dev/null
}

case $1 in
    start | restart | reload)
        stop
        start
        break
    ;;

    stop)
        stop
        break
    ;;

    *)
        echo "Usage: init-script.sh (start|stop|restart|reload)"
    ;;
esac
