/**************************************************************************
 * khtmld - khtml2png daemon                                              *
 * Copyright (C) 2005 by Julian 'JayPiKay' Knauer                         *
 * Copyright (C) 2007 by Florent Bruneau                                  *
 *                                                                        *
 * khtml daemon - daemon.c                                                *
 * http://goatpron.de                                                     *
 *                                                                        *
 * Description:                                                           *
 *   Daemon listen on pipe for input to run khtml2png                     *
 *                                                                        *
 * khtml2png can be found at:                                             *
 *   http://khtml2png.sourceforce.net                                     *
 *                                                                        *
 * This program is free software; you can redistribute it and/or          *
 * modify it under the terms of the GNU General Public                    *
 * License as published by the Free Software Foundation; either           *
 * version 2 of the License, or (at your option) any later version.       *
 *                                                                        *
 * This program is distributed in the hope that it will be useful,        *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      *
 * General Public License for more details.                               *
 *                                                                        *
 * You should have received a copy of the GNU General Public License      *
 * along with this program; see the file COPYING.  If not, write to       *
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330,       *
 * Boston, MA 02111-1307, USA.                                            *
 **************************************************************************/
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <syslog.h>
#include <getopt.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <errno.h>
#include <pwd.h>

#define VERSION "0.2.2"
#define HOMEPAGE_J "http://goatpron.de"
#define HOMEPAGE_F "http://fruneau.rznc.net"

/* GLOBAL DEFAULTS + CONSTANTS */
#define BUFSIZE 8192
#define CMDLINESIZE 4096
#define CMDLINEOPTS 32
#define DAEMONPID "/tmp/khtmld.pid"
#define KHTML "/usr/local/bin/khtml2png"
#define SPOOL "/tmp/khtmldspool"

const char helptext[] = "Usage:\n"
    "  khtmld [-Dh] [-K <khtml2png>] [-s file] [-p file] [-t interval]\n\n"
    "Parameter         Description\n"
    "--daemon, -D      Start khtmld as background daemon.\n"
    "--help, -h        Shows short help and commands.\n"
    "--config, -c      khtml2png parameter configuration file.\n"
    "--khtml2png, -K   Specify kthml2png path. (Default: /usr/local/bin/khtml2png)\n"
    "--spool, -s       Specify FIFO/Pipe. (Default: /tmp/khtmldspool)\n"
    "                  If a FIFO/Pipe does not exist, it will be created.\n"
    "--pid, -p         Sepcify PID file.\n"
    "--user, -u        Specifty the user who run khtml2png\n"
    "--timeout, -t     Set timeout interval until child process gets terminated.\n\n"
    "While khtmld is running write your command to spool. First write the URL and\n"
    "seperated by one space the screenshot destination.\n\n"
    "Example:\n"
    "  http://www.website.com img_dir/website.png\n";

/* argument switches and variables */
char *khtmlpath = (char*)KHTML;
char *spoolpath = (char*)SPOOL;
char *pidpath   = (char*)DAEMONPID;
struct passwd *pwd = NULL;
gid_t group     = 0;
int Dflag       = 0; // daemom
int timeout     = 60;
int killpid     = -1;

/* KHTML2PNG arguments:
 *  { khtmlpath,
 *    "--nocrashhandler",
 *    ...
 *    url,
 *    file,
 *    NULL
 *  }
 */
char *k2pconfig[CMDLINEOPTS];
int confsize    = 0;

/* SIGINT handle ^C-c to terminate program */
static void exit_daemon(int sig) 
{
    char c;

    if (sig != SIGINT) {
        return;
    } else {
        fprintf(stderr, "Do you really want to quit? (y/[n]): ");
        while ((c = getchar()) != 'y') {
            return;
        }

        unlink(pidpath);
        closelog();
        exit(0);
    }
}

/* SIGALRM handle to terminate child processes, when triggered by externel
 * application process with `killpid' pid get terminated. */
static void alarm_daemon(int sig)
{
    if (killpid > 0) {
        kill(killpid, sig);
        fprintf(stderr, "==> The daemon made a boo boo <==\n");
    }
    return;
}

static void readConfig(const char *cfg)
{
    const char delimiters[] = " ="; // split on spaces and =
    char *p;
    char s[128];
    char *t1, *t2;
    FILE *fp;
    confsize = 2;

    k2pconfig[0] = khtmlpath;
    k2pconfig[1] = (char*)"--nocrashhandler";
    fp = fopen(cfg, "r");
    if (fp) {
        while (confsize < CMDLINEOPTS - 4 && fgets(s, 128, fp)) {
            s[127] = '\0';
            s[strlen(s) - 1] = 0;
            p = s;

            /* this while looks a bit crappy and it is not very tolerant for mistakes */
            while (confsize < CMDLINEOPTS - 4 && (t1 = strsep(&p, delimiters)) && (t2 = strsep(&p, delimiters))) {
                k2pconfig[confsize] = (char*)malloc(strlen(t1) + 3);
                sprintf(k2pconfig[confsize++], "--%s", t1);
                k2pconfig[confsize] = (char*)malloc(strlen(t2) + 1);
                strcpy(k2pconfig[confsize++], t2);
            }
        }
        k2pconfig[confsize]   = NULL;
        k2pconfig[confsize+1] = NULL;
        k2pconfig[confsize+2] = NULL;
        fclose(fp);
    }
}

/* Open/Create PIPE/FIFO and return handle */
static int mount_fifo(const char *spool)
{
    struct stat attr;
    int fp = -1;

    if (stat(spool, &attr) == -1) {
        if (mkfifo(spool, O_RDWR|0666) == -1) {
            return -1;
        }
        stat(spool, &attr);
    }
    if (S_ISFIFO(attr.st_mode)) { // is `spool' a FIFO file
        fp = open(spool, O_RDONLY);
    } else {
        fprintf(stderr, "ERROR: FIFO `%s' already exsists, and is no pipe!\n",
                spool);
    }
    
    if (fp != -1) { // To be sure, that we can read/write the FIFO
        chmod(spool, S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP|S_IROTH|S_IWOTH);
    }

    return fp; // return file handle
}

static void read_fifo(void) 
{
    int fp;
    int n, i;
    char buf[BUFSIZE];
    int status;
    pid_t pid;

    fprintf(stderr, "Mounting fifo...\n");
    fp = mount_fifo(spoolpath);

    if (fp == -1) {
        syslog(LOG_CRIT, "Error reading from pipe!");
        exit(0);
    }

    for (i = 0; i < BUFSIZE; i++) {
        buf[i] = '\0';
    }

    k2pconfig[confsize] = (char*)malloc(CMDLINESIZE);
    k2pconfig[confsize][CMDLINESIZE - 1] = 0;
    /* Read spool */
    while (read(fp, buf, BUFSIZE) > 0) {
        fprintf(stderr, "New jobs in spool, working...\n");
        i = 0;
        n = 0;
        while (buf[n] != '\0' && i < CMDLINESIZE - 1) {
            k2pconfig[confsize][i++] = buf[n++];
            if (buf[n - 1] == ' ') { // Indicate the end of the url
                k2pconfig[confsize+1] = k2pconfig[confsize] + i;
                k2pconfig[confsize][i - 1] = 0;
            }
            if (buf[n] == '\n' || buf[n] == '\0') {
                k2pconfig[confsize][i] = '\0';
                pid = fork(); // put khtml2png into background
                killpid = pid;
                alarm(timeout); // enable alarm signal
                if (pid == 0) {
                    status = 0;
                    if (!pwd || (!setgid(pwd->pw_gid) && !setreuid(pwd->pw_uid, pwd->pw_uid))) {
                        if (pwd) {
                            setenv("HOME", pwd->pw_dir, 1);
                            setenv("USER", pwd->pw_name, 1);
                        }
                        execv(khtmlpath, k2pconfig); // start khtml2png
                    } else {
                        syslog(LOG_CRIT, "SU on %d failed", pwd->pw_uid);
                    }
                    _exit(EXIT_FAILURE);
                } else if (pid < 0 || waitpid(pid, &status, 0) != pid) {
                    status = -1;
                }
                alarm(0); // disable alarm signale
                killpid = -1;

                n++;
                i = 0;
                k2pconfig[confsize + 1] = NULL;
            }
        }
        fprintf(stderr, "All current spool jobs done.\n");
    }
    free(k2pconfig[confsize]);
    close(fp);
    return;
}

static void printHelp(void)
{
    fprintf(stderr, "%s", helptext);
}

static void printVersion(void)
{
    fprintf(stderr, "khtmld(aemon) version %s.\n"
            "Copyright (C) 2005 by Julian 'JayPiKay' Knauer (Homepage: %s)\n"
            "Copyright (C) 2007 by Floren Bruneau (Homepage: %s)\n", VERSION, HOMEPAGE_J, HOMEPAGE_F);
}

int main(int argc, char **argv)
{
    int c, option_index = 0;
    FILE *fp;
    char *rcpath = NULL;
    static struct option long_options[] = {
        {"spool"    , required_argument, 0, 's'},
        {"khtml2png", required_argument, 0, 'K'},
        {"help"     , no_argument,       0, 'h'},
        {"config"   , required_argument, 0, 'c'},
        {"daemon"   , no_argument,       &Dflag, 1},
        {"pid"      , required_argument, 0, 'p'},
        {"timeout"  , required_argument, 0, 't'},
        {"user"     , required_argument, 0, 'u'},
        {"version"  , no_argument,       0, 'V'},
        {0, 0, 0, 0}
    };

    /* register signal handlers */
    signal(SIGINT, exit_daemon);
    signal(SIGALRM, alarm_daemon);

    k2pconfig[0] = '\0';
    
    /* parse command parameters */
    while ((c = getopt_long(argc, argv, "s:K:hc:Dp:t:Vu:", long_options, &option_index)) != -1) {
        switch (c) {
          case 0:
            if (long_options[option_index].flag != 0) {
                break;
            }
            fprintf(stderr, "Option `%s'", long_options[option_index].name);
            if (optarg) {
                fprintf(stderr, " with arg `%s'", optarg);
            }
            fprintf(stderr, "\n");
            break;
          case 's':
            spoolpath = optarg;
            break;
          case 'K':
            khtmlpath = optarg;
            break;
          case 'h':
            printHelp();
            return EXIT_SUCCESS;
          case 'c':
            rcpath = optarg;
            break;
          case 'V':
            printVersion();
            return EXIT_SUCCESS;
          case 'D':
            Dflag = 1;
            break;
          case 'p':
            pidpath = optarg;
            break;
          case 't':
            timeout = atoi(optarg);
            break;
          case 'u':
            pwd = getpwnam(optarg);
            break;
          case '?':
            if (isprint(optopt)) {
                fprintf(stderr, "Unknown option `-%c'.\n", optopt);
            } else {
                fprintf(stderr, "Unknown option character `\\x%c'.\n", optopt);
            }
            return 1;
          default:
            abort();
        }
    }
    
    /* Do some informational stuff to stdout */
    fprintf(stdout, "Using khtml2png at location `%s'.\n", khtmlpath);
    fprintf(stdout, "Using spool `%s' for input processing.\n", spoolpath);
    fprintf(stdout, "Using pidfile `%s'.\n", pidpath);
    fprintf(stdout, "Using config from `%s'\n", rcpath);
    if (pwd) {
        fprintf(stdout, "Use khtml2png with uid `%d'.\n", pwd->pw_uid);
    }
    if (Dflag) {
        fprintf(stdout, "Starting khtmld into background.\n");
        if (daemon(1, 0)) {
            perror("Daemonizing khtmld.");
            return EXIT_FAILURE;
        }
    }
    fprintf(stdout, "Fork timeout set to: `%d'\n", timeout);
    openlog("khtml daemon", LOG_PID|LOG_PERROR, LOG_DAEMON);

    /* read configuration file */
    if (!rcpath) {
        rcpath = (char *)malloc(sizeof(char) * (strlen(getenv("HOME")) + 11));
        sprintf(rcpath, "%s/.khtmldrc", getenv("HOME"));
        readConfig(rcpath);
        free(rcpath);
    } else {
        readConfig(rcpath);
    }

    /* Decide where to store pid */
    fp = fopen(pidpath, "w"); 
    if (fp) {
        fprintf(fp, "%d", getpid());
        fclose(fp);
    } else {
        perror("PID file creation.");
        abort();
    }

    syslog(LOG_NOTICE, "khtmld started and listening.\n");
    /* main-loop */
    while (1) { 
        read_fifo();
    }

    syslog(LOG_NOTICE, "khtmld shutdown.\n");
    closelog();
    return EXIT_SUCCESS;
}
